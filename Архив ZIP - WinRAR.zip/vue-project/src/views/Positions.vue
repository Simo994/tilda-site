<script setup lang="ts">

</script>

<template>
  <div class="wrapper">Должности</div>
</template>
