<script setup lang="ts">

</script>

<template>
  <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tilda Publishing</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css">

</head>
<body class="font-roboto text-gray-700 bg-white">


  <header class="flex justify-between items-center p-6">
    <h1 class="text-lg font-semibold">Tilda Publishing</h1>
    <nav class="space-x-8 text-sm text-gray-800">
        <a href="#" class="hover:underline">ГЛАВНАЯ</a>
        <a href="#" class="hover:underline">ТАРИФЫ</a>
        <a href="#" class="hover:underline">СООБЩИТЬ О НАРУШЕНИИ</a>
    </nav>
</header>

  <main class="main-content">
    <h1 class="title"><span>Создайте впечатляющий <br>сайт на Tilda</span> для бизнеса и медиа</h1><br>
    <p class="subtitle">550+ профессиональных блоков готовых для вашего сайта и интернет-магазина</p>

    <div class="cta-button">
      <button>Тарифы</button><br>
    </div>

    <section class="section">
      <h2 class="section-title">Как сделать тысячи людей счастливыми?</h2>
      <p class="section-text">
        Мы придумали новый способ создания сайтов, где процесс похож на игру. Теперь каждый — дизайнер, если есть страсть к любимому делу.
        Независимо, что вы делаете: сайт для бизнеса, лендинг пейдж, интернет-магазин или редакторский спецпроект — с Тильдой вы сделаете это быстро и легко.
      </p>
    </section>

    <section class="feature-section">
      <img src="" alt="Website builder example" class="feature-image">
      <div class="feature-text">
        <h3 class="feature-title">Интуитивный конструктор сайтов</h3><br>
        <p class="feature-description">
          Создание сайта самостоятельно с помощью блоков из библиотеки Tilda. <br><br> Используйте блоки в сотнях комбинаций, просто добавляя один за другим, в интуитивно понятном интерфейсе. Вы сможете создать <a href="#" class="link">сайт своими руками</a>.
        </p>
      </div>
    </section>

    <section class="block-library">

      <h3 class="library-title">Библиотека блоков</h3>
      <p class="library-description">
        Полноэкранные обложки, эффектная типографика, фотографии, фоновые видео, формы заявок и многое другое.
        Вам не обязательно быть дизайнером. Создано более 550 блоков. Каждый из них гармоничен, и в то же время имеет настройки, позволяющие создать сайт с индивидуальным дизайном.
      </p>
      <img src="" alt="Block" class="block">

    </section>
  </main>

</body>
</template>

