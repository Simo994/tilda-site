import { RouteRecordRaw } from "vue-router"
import Home from "@/views/Home.vue"

const routes: Array<RouteRecordRaw> = [
    {
        path: '/',
        component: Home,
    },
    {
        path: '/departments',
        component: () => import('@/views/Departments.vue'),
    },
    {
        path: '/positions',
        component: () => import('@/views/Positions.vue'),
    },
]

export default routes
